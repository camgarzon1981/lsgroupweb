<?php
$footer = '
		<table><tr><td align="center">SEFT Ltda</td></tr></table></body>
</html>';
?>