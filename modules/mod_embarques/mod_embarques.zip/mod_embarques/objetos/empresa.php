<?php
class empresa {
	public $nit;
	public $nombre;
	public $campos= array();
	public $campos_cliente= array();
	public $campos_mail= array();
	public $usuarios=array();
}
?>