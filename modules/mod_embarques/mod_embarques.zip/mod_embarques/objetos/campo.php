<?php

class campo {
	public $nombre;
	public $etiqueta;
	public $tipo;
	public $obligatorio;
	public $orden;
}
?>