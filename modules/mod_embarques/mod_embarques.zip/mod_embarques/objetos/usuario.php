<?php
class usuario {
	public $id;
	public $rol;
}
?>