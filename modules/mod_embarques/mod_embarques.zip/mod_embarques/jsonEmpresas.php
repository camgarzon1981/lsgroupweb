<?php
require 'modules/mod_embarques/servicios/funcionesDynamo.php';
getTableEmpresas();
?>