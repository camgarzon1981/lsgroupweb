<?php 
/** * version $Id: mod_embarques.php 2017-03-12 Ed $ 
* @package Joomla.Site 
* @subpackage mod_embarques 
* @copyright Copyright (C) 2017 Camilo Garzon 
* @license Private see License.txt 
* */ 
define('_JEXEC') or die; 
require_once dirname(__FILE__).'/helper.php'; ?>
<p>Modulo de seguimiento de embarques</p>